// EditBMPVCDlg.cpp : implementation file
//

#include "stdafx.h"
#include "EditBMPVC.h"
#include "EditBMPVCDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditBMPVCDlg dialog

CEditBMPVCDlg::CEditBMPVCDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEditBMPVCDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEditBMPVCDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CEditBMPVCDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEditBMPVCDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CEditBMPVCDlg, CDialog)
	//{{AFX_MSG_MAP(CEditBMPVCDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1_EditPixelExample)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3_BrowseImageFile)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2_FileHeaderInfo)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4_BrowseTextFile)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5_WriteMessage)
	ON_BN_CLICKED(IDC_BUTTON6, OnButton6_ReadMessage)
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1_WholeFile)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2_PercentCapacity)
	ON_BN_CLICKED(IDC_RADIO3, OnRadio3_FillFixedData)
	ON_CBN_SELCHANGE(IDC_COMBO3, OnSelchangeCombo3_ChangeProfile)
	ON_BN_CLICKED(IDC_BUTTON7, OnButton7_WriteMessageToAllFiles)
	ON_BN_CLICKED(IDC_BUTTON8, OnButton8_BrowseStegoFile)
	ON_BN_CLICKED(IDC_CHECK1, OnCheck1_UsePassword)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditBMPVCDlg message handlers


#include<direct.h>
#include<io.h>
#include<math.h>


#include"fun/Generalfun.cpp"
#include "editbmp/editbmp.h"
#include"fun/upfun.cpp"





struct DLGSETTING
{
	char ImageFilePath[500],ImageFilePathOut[500],ImageFileTitle[500],ImageFileName[500];
	char TextFilePath[500]; //,TextFilePathOut[500];
	char DataGroupSize[100],PixelGroupSize[100],StartDataPixel[100];
	char DataPixelMapping[500];
	int  nProfile;
	int RadioValueMsgSize; char PercentData[30],FixedData[30];
}dlgset;






BOOL CEditBMPVCDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	GetTempFolderPath();

	//Read settings from settings.stg file
	char buff[500]; 
	sprintf(buff,"%s\\settings.stg",TempFolder);
	FILE *fp=fopen(buff,"rb"); 
	if(fp==NULL)
	{ 
		dlgset.ImageFilePath[0]=dlgset.ImageFilePathOut[0]=0; 
	    strcpy(dlgset.DataGroupSize,"3"); 
		strcpy(dlgset.PixelGroupSize,"2"); 
		strcpy(dlgset.StartDataPixel,"0"); 
		strcpy(dlgset.DataPixelMapping,"0,1,2,3,4,5");
		dlgset.RadioValueMsgSize=0;
		strcpy(dlgset.PercentData,"100 %"); 
		strcpy(dlgset.FixedData,"16 KB"); 
		dlgset.nProfile=0;
		//return(TRUE); 
	}
	else
	{
		fread(&dlgset,sizeof(DLGSETTING),1,fp); 
		fclose(fp);
	}

	//Read QR_Info struct (To unhide information from stego file)
	//Read_INFO_struct();

 	//Display dialog fields
	SetDlgItemText(IDC_STATIC1,dlgset.ImageFilePath);
	SetDlgItemText(IDC_STATIC2,dlgset.TextFilePath);
	SetDlgItemText(IDC_STATIC3,dlgset.ImageFilePathOut);
	SetDlgItemText(IDC_EDIT1,dlgset.DataGroupSize);
	SetDlgItemText(IDC_EDIT2,dlgset.PixelGroupSize);
	SetDlgItemText(IDC_EDIT3,dlgset.StartDataPixel);
	SetDlgItemText(IDC_EDIT4,dlgset.DataPixelMapping);


	//Percent Fill Combobox
	((CComboBox*)GetDlgItem(IDC_COMBO1))->ResetContent();
	for(int i=1;i<=100;i++)
	{
		sprintf(buff,"%d %%",i);
		((CComboBox*)GetDlgItem(IDC_COMBO1))->AddString(buff);
	}
	//((CComboBox*)GetDlgItem(IDC_COMBO1))->SetCurSel(0);
	SetDlgItemText(IDC_COMBO1,dlgset.PercentData);

	//Fixed data combo box
	char *fixdata[50]={ "","256 bytes","512 bytes", "1 KB","2 KB", "3 KB","4 KB","5 KB","10 KB","15 KB","20 KB","25 KB","30 KB","35 KB","40 KB","45 KB","50 KB","60 KB","70 KB","80 KB","90 KB","100 KB","150 KB","200 KB","300 KB","400 KB","500 KB","600 KB","700 KB","800 KB","900 KB",""};

	((CComboBox*)GetDlgItem(IDC_COMBO2))->ResetContent();
	for(i=1;i<=fixdata[i][0]!=0;i++)
	{
		sprintf(buff,"%s",fixdata[i]);
		((CComboBox*)GetDlgItem(IDC_COMBO2))->AddString(buff);
	}
	//((CComboBox*)GetDlgItem(IDC_COMBO2))->SetCurSel(0);
	SetDlgItemText(IDC_COMBO2,dlgset.FixedData);

	//Profile combobox
	char *profile[50]={ "","3 chars -> 2 Pixels   (1.5 byte/pixel)","1 char -> 1 Pixel      (1 byte/pixel)","3 chars -> 4 Pixels   (0.75 byte/pixel)","2 chars -> 3 Pixels   (0.66 byte/pixel)","1 char -> 2 Pixels    (0.50 byte/pixel)","2 chars -> 5 Pixels   (0.40 byte/pixel)","1 char -> 3 Pixels    (0.33 byte/pixel)",""};
	((CComboBox*)GetDlgItem(IDC_COMBO3))->ResetContent();
	for(i=1;i<=profile[i][0]!=0;i++)
	{
		sprintf(buff,"%s",profile[i]);
		((CComboBox*)GetDlgItem(IDC_COMBO3))->AddString(buff);
	}
	((CComboBox*)GetDlgItem(IDC_COMBO3))->SetCurSel(dlgset.nProfile);

	//Set default Radio button
	if(dlgset.RadioValueMsgSize<0 || dlgset.RadioValueMsgSize>2)dlgset.RadioValueMsgSize=0;
	((CButton*)GetDlgItem(IDC_RADIO1+dlgset.RadioValueMsgSize))->SetCheck(1);
	if(dlgset.RadioValueMsgSize==0)OnRadio1_WholeFile();
	if(dlgset.RadioValueMsgSize==1)OnRadio2_PercentCapacity();
	if(dlgset.RadioValueMsgSize==2)OnRadio3_FillFixedData();

	//Hide Some controls
	GetDlgItem(IDC_BUTTON1)->ShowWindow(0);
	GetDlgItem(IDC_BUTTON7)->ShowWindow(0);

	//Disable Some Controls
	GetDlgItem(IDC_EDIT1)->EnableWindow(0);
	GetDlgItem(IDC_EDIT2)->EnableWindow(0);
	GetDlgItem(IDC_EDIT3)->EnableWindow(0);
	GetDlgItem(IDC_EDIT4)->EnableWindow(0);
	OnCheck1_UsePassword(); //Enable Disable Password field

 	return TRUE;  // return TRUE  unless you set the focus to a control
}





void CEditBMPVCDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}


// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CEditBMPVCDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CEditBMPVCDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}




void CEditBMPVCDlg::OnButton3_BrowseImageFile() 
{
	//Select filename
	CFileDialog  file(TRUE,NULL,NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,"Bitmap Files (*.bmp)|*.bmp|All Files (*.*)|*.*||",NULL);
    if(file.DoModal()==IDCANCEL)return;
    
	//Save ImageFile Path and Name to struct
	strcpy(dlgset.ImageFilePath,file.GetPathName()); strlwr(dlgset.ImageFilePath);
	strcpy(dlgset.ImageFileTitle,file.GetFileName()); strlwr(dlgset.ImageFileTitle);

	//Validate selected file
    CString st=dlgset.ImageFilePath; st.MakeLower();  int pos=st.Find(".bmp");
    if(pos==-1){ AfxMessageBox("Browse file with .bmp extension only"); return; }

	//Get Output filename
	//strcpy(dlgset.ImageFilePathOut,FindOutputFileName(dlgset.ImageFilePath)); 

	//Display Loaded file name
	SetDlgItemText(IDC_STATIC1,dlgset.ImageFilePath);
}



char* GetSaveAsFileName(char *filetypes) 
{
	static char fname[500]; fname[0]=0;
	//Select filename
	CFileDialog  file(FALSE,NULL,NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,filetypes,NULL);
    if(file.DoModal()==IDCANCEL)return(fname);

	strcpy(fname,file.GetPathName()); 
	strlwr(fname);
	if(strcmp(fname+strlen(fname)-4,".bmp"))strcat(fname,".bmp"); 

	return(fname);
}




//Browse and Display Text file in editbox
void CEditBMPVCDlg::OnButton4_BrowseTextFile() 
{
	//Select filename
	CFileDialog  file(TRUE,NULL,NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,"Text Files (*.txt)|*.TXT|All Files (*.*)|*.*||",NULL);
    if(file.DoModal()==IDCANCEL)return;
    
	//Save TextFile Path to struct
	strcpy(dlgset.TextFilePath,file.GetPathName());

	//Get Output filename
	//strcpy(dlgset.TextFilePathOut,FindOutputFileName(dlgset.TextFilePath)); 

	//Display Loaded file name
	SetDlgItemText(IDC_STATIC2,dlgset.TextFilePath);

}



void CEditBMPVCDlg::OnButton2_FileHeaderInfo() 
{

	if(dlgset.ImageFilePath[0]==0){ MessageBox("Select .bmp file first.","Select File"); return; }
  MessageBox(EditBMP::DisplayFileHeader(dlgset.ImageFilePath),"Header Information");	 
}




//1=read and 0=write
//Reads or writes  QR_INFO struct from/To end of stego .BMP file.
void ReadWriteInfo(int read,EditBMP *bmp,QR_INFO *info)
{

	int size=sizeof(QR_INFO);
	size=size/3+1;
	int structstartpixel=bmp->pixelwidth*bmp->pixelheight-1-size;

	char *ptrpixel=bmp->GetPixel(structstartpixel%bmp->pixelwidth, structstartpixel/bmp->pixelwidth);

	if(read) *info=*((QR_INFO*)ptrpixel); else *((QR_INFO*)ptrpixel)=*info;
}



int SetMessageSize(char *msg,int RadioValueMsgSize, char *PercentFixed, int capacity)
{

	int len=strlen(msg);

	if(RadioValueMsgSize==0)return(len);

	if(RadioValueMsgSize==1)
	{
		int percent=atoi(PercentFixed);
		int value=(capacity*percent)/100;
		if(value<len) { msg[value]=0; return(value); } else return(len);
	}

	if(RadioValueMsgSize==2)
	{
		char buff[100]; strncpy(buff,PercentFixed,95)[95]=0; strlwr(buff);
		int fixed=atoi(buff); 
		if(strstr(buff,"kb")!=NULL) fixed*=1024;
		if(strstr(buff,"mb")!=NULL)fixed*=1024*1024;
		if(fixed<len){ msg[fixed]=0; return(fixed); } else return(len);
	}

	return(len);
}




int RowMsgOn=0; char RowMsg[1000];
void CEditBMPVCDlg::OnButton5_WriteMessage() 
{

	//Read Text file to msg[]
	char *msg;
	if(dlgset.TextFilePath[0]==0){ MessageBox("Browse Message Text file first"); return; }
	FILE *fp=fopen(dlgset.TextFilePath,"rb"); 
	if(fp==NULL){ MessageBox("Error: Unable to open Message text file"); return; }
	int flen=_filelength(fileno(fp));
	msg=new char[flen+100];
	fread(msg,flen,1,fp); msg[flen]=0; 
	fclose(fp);

	//Debug
	//sprintf(buff,"msglen=%d",val1); MessageBox(buff);

	//Find 1st four variables of INFO struct. 
	CreateNewAsciiCharArray(msg);

	//Find StepSize1, StepSize2 of INFO struct
	FindDivider_StepSizes(Info.TNewAsciichar);

	//Open .bmp file
	EditBMP bmp;
	if(bmp.ReadBMPFile(dlgset.ImageFilePath)==0){ MessageBox("Browse Original Image file first"); return; }

	//Find max. Capacity of Cover using current mapping.
	char buff[1000]; 
	GetDlgItemText(IDC_EDIT1,buff,15); int TGroupData1=atoi(buff);
	GetDlgItemText(IDC_EDIT2,buff,15); int TGroupPixels1=atoi(buff);
	int capacity= ((bmp.pixelwidth*bmp.pixelheight - ((Info.TNewAsciichar*2)/3+5) )/TGroupPixels1)*TGroupData1;

	//Set msg[] length
	if(dlgset.RadioValueMsgSize==1)GetDlgItemText(IDC_COMBO1,buff,15); 
	if(dlgset.RadioValueMsgSize==2)GetDlgItemText(IDC_COMBO2,buff,15);
	int val1=SetMessageSize(msg, dlgset.RadioValueMsgSize, buff, capacity);

	//Recalculate parameters because msg may not be original full text file.
	Info.TotalMsgChars=val1;
	CreateNewAsciiCharArray(msg);
	FindDivider_StepSizes(Info.TNewAsciichar);


	QR_EMBED qr;
	if(qr.Init(&Info,&bmp,this)==0)return; 

	//Check if data can be embedded.
	//Get details
	char buff2[2000];
	sprintf(buff2,"Data: %d bytes (%d KB)\nData Hiding Capacity: %d bytes (%d KB)\nPercent Cover Used: %2.3lf%% \nImage PixelSize=%dx%d=%d \nImage PixelBytes=%d",    qr.info->TotalMsgChars, qr.info->TotalMsgChars/1024, capacity, capacity/1024,  float(qr.info->TotalMsgChars*100)/capacity,   bmp.pixelwidth,   bmp.pixelheight,   bmp.pixelwidth*bmp.pixelheight,   bmp.pixelwidth*bmp.pixelheight*3);
	//if(!RowMsgOn)MessageBox(buff2);

	if(RowMsgOn)
	{
		//Results="File, DataBytes,  Cover Capacity(Bytes),    %Cover Used, Pixel(WxH), TotalPixels, AllPixelBytes, Unique ASCII Chars, Divider, StepSize1, StepSize2\n";
		sprintf(RowMsg,"%s,  %d, %d, ",  dlgset.ImageFileTitle,  qr.info->TotalMsgChars,  capacity);
		sprintf(RowMsg+strlen(RowMsg),"%2.3lf%%, %dx%d, ", float(qr.info->TotalMsgChars*100)/capacity, bmp.pixelwidth, bmp.pixelheight);
		sprintf(RowMsg+strlen(RowMsg),"%d, %d, ", bmp.pixelwidth*bmp.pixelheight,  bmp.pixelwidth*bmp.pixelheight*3);
		sprintf(RowMsg+strlen(RowMsg),"%d, %d, %d, %d", Info.TNewAsciichar,Info.Divider,Info.StepSize1,Info.StepSize2);
	}

	if(qr.info->TotalMsgChars>capacity)
	{ 
		if(RowMsgOn) strcat(RowMsg, "----->Lower Cover Capacity\n");
		else 
		{
			char buff[500];
			sprintf(buff,"Unable to embedd large data as compared to Cover capacity\n\nData: %d bytes\nCover Capacity: %d bytes",qr.info->TotalMsgChars,capacity);
			MessageBox(buff,"Large Data"); 
		}
		return; 
	}
	strcat(RowMsg, "\n");

	//Init static variables in functions
	qr.GetDataGroup(1);
	qr.StegoPixelBytes(1); 

	//Write data to cover
	int n=strlen(msg)/qr.TGroupData;  
	if(strlen(msg)%qr.TGroupData!=0)n++;
	for(int i=0;i<n;i++)
	{ 
		qr.GetDataGroup(); 
		qr.StegoPixelBytes(); 
	}

	//Get Password information
	int IsPass=((CButton*)GetDlgItem(IDC_CHECK1))->GetCheck();
	GetDlgItemText(IDC_EDIT5,buff,7);
	int Password=atoi(buff);

	//Get Input Profile
	int profile=((CComboBox*)GetDlgItem(IDC_COMBO3))->GetCurSel();

	//Write original unique characters to bmp file
	WriteArrayToBMPEnd(Info.NewAsciichar,Info.TNewAsciichar, &bmp,IsPass,Password,profile);

	//Get Output filename
	//strcpy(dlgset.ImageFilePathOut,FindOutputFileName(dlgset.ImageFilePath)); 

	//Show embedding information
	//if(!RowMsgOn)MessageBox(Display_INFO_struct(buff2),"Embedding Information");

	char *fname=GetSaveAsFileName("Bitmap Stego Files (*.bmp)|*.bmp|All Files (*.*)|*.*||"); 
	if(fname[0]==0)return;
	strlwr(fname);

	//Save stego file
	bmp.WriteBMPFile(fname);

	delete msg;

	//ShellExecute(NULL,_T("open"),ImageFilePathOut,NULL,NULL,SW_SHOW);
}

/*
struct DLGSETTING
{
	char ImageFilePath[500],ImageFileName[500],ImageFilePathOut[500];
	char TextFilePath[500],TextFilePathOut[500];
	char DataGroupSize[20],PixelGroupSize[20],StartDataPixel[20];
	char DataPixelMapping[500];
}dlgset;
*/


//Replaces  'infname1'  'outfname1'  'titlefname1'  variables in  *.gen files 
//with *Infname,*Outfname, *Titlefname filenames having 'count' files. and copies to *.m file.
void ReplaceMatlabNames(CString *Infname, CString *Outfname, CString *Titlefname, int count)
{

	CString FilePath[50],FileTitle[50],FileName[50],FolderPath,Results;
	int nFiles=GetFolderFilePaths(dlgset.ImageFilePath, FilePath, FileTitle, FileName, &FolderPath,".gen", "", 100);

	FILE *fp;  CString strbuff; char *fbuff,t1[500],t2[500],t3[500]; int flen;
	for(int i=0;i<nFiles && i<48;i++)
	{
		//Read file to strbuff
		fp=fopen(FilePath[i],"rb"); if(fp==NULL){ AfxMessageBox("Unable to open .gen file"); continue; }
		flen=filelength(fileno(fp)); 
		fbuff=new char[flen+2000]; 
		fread(fbuff,flen,1,fp); 
		fbuff[flen]=0; fclose(fp);
		strbuff=fbuff; 
		delete fbuff;

		//Debug
		//char b1[500]; sprintf(b1,"flen=%d\nstrbuff len=%d",flen,strbuff.GetLength()); AfxMessageBox(b1);

		//Replace infname1, outfname1, and so on in strbuff.
		for(int j=0;j<count;j++)
		{
			sprintf(t1,"infname%d",j+1); 
			sprintf(t2,"outfname%d",j+1); 
			sprintf(t3,"titlefname%d",j+1);
			strbuff.Replace(t1,Infname[j]);  
			strbuff.Replace(t2,Outfname[j]); 
			strbuff.Replace(t3,Titlefname[j]);
		}

		//Create *.m file (Note: opening file in text mode appends unknown extra chars after it is saved)
		sprintf(t1,"%s\\%s.m",FolderPath,FileTitle[i]);
		fp=fopen(t1,"wb"); if(fp==NULL){ AfxMessageBox("Unable to create .m file"); continue; }
		fwrite(strbuff,1,strbuff.GetLength(),fp);  
		fclose(fp);
	}

}



void CEditBMPVCDlg::OnButton7_WriteMessageToAllFiles() 
{

	CString FilePath[50],FilePathOut[50],FileTitle[50],FileName[50],FileNameOut[50],FolderPath,Results;

	Results="File, DataBytes,  Cover Capacity(Bytes),  %Cover Used, Pixel(WxH), TotalPixels, AllPixelBytes, Unique ASCII Chars, Divider, StepSize1, StepSize2\n";

	int nFiles=GetFolderFilePaths(dlgset.ImageFilePath, FilePath, FileTitle, FileName, &FolderPath,".bmp", "Stego-", 50);
	for(int i=0;i<nFiles;i++)
	{
		FileNameOut[i]=FindOutputFileName(LPCSTR(FileName[i]));
		FilePathOut[i]=FindOutputFileName(LPCSTR(FilePath[i]));
	}

	//Save existing filenames
	DLGSETTING dlgset1=dlgset;

	RowMsgOn=1;
	for(i=0;i<nFiles;i++)
	{
		//Load dlgset with new filenames
		strcpy(dlgset.ImageFilePath,FilePath[i]);
		strcpy(dlgset.ImageFileTitle,FileTitle[i]);
		strcpy(dlgset.ImageFileName,FileName[i]);
		strcpy(dlgset.ImageFilePathOut,FilePathOut[i]);

		OnButton5_WriteMessage();
		Results+=RowMsg;
	}
	RowMsgOn=0;

	dlgset=dlgset1;

	//Save results in *.csv file
	char buff[500];
	sprintf(buff,"%s//Result1.csv",FolderPath);
	FILE *fp=fopen(buff,"wt"); if(fp==NULL){ MessageBox("Unable to create Details.csv"); return; }
	fprintf(fp,"%s",Results);
	fclose(fp);

	//Generate .m files from .gen files
	ReplaceMatlabNames(FileName, FileNameOut, FileTitle, nFiles);

	//Open *.csv file
	ShellExecute(NULL,_T("open"),buff,NULL,NULL,SW_SHOW);

}






void CEditBMPVCDlg::OnButton6_ReadMessage() 
{
	
	//Check if Stego file is loaded or not.
	if(dlgset.ImageFilePathOut[0]==0){ MessageBox("Select Stego-Image file first","File not browsed"); return; }
	FILE *fp1=fopen(dlgset.ImageFilePathOut,"rb");
	if(fp1==NULL){ MessageBox("Select Stego-Image file first","File not browsed"); return; } else fclose(fp1);


	EditBMP bmp;
	bmp.ReadBMPFile(dlgset.ImageFilePathOut);

	//Read profile and change it in dialog from where qr.Init() will read dialog fields
	int Tpixels=bmp.pixelheight*bmp.pixelwidth;
  	bmp.GetPixel(Tpixels-3);
	int Profile=bmp.g&15; 
	((CComboBox*)GetDlgItem(IDC_COMBO3))->SetCurSel(Profile);
	OnSelchangeCombo3_ChangeProfile();

	//Get Password
	char buff[500];
	GetDlgItemText(IDC_EDIT5,buff,7);
	int Password=atoi(buff);

	//Read Info struct from bmp file end
	Info.TNewAsciichar=ReadArrayFromBMPEnd(Info.NewAsciichar, &bmp, Password);
	if(Info.TNewAsciichar==-1){ MessageBox("This file does not contain any hidden information","No Information"); return; }
	if(Info.TNewAsciichar==-2){ MessageBox("Password protected!! Enter password..","Password Protected"); return; }
	if(Info.TNewAsciichar==-3){ MessageBox("Password is incorrect.","Password Incorrect"); return; }

	FindDivider_StepSizes(Info.TNewAsciichar);

	QR_EMBED qr;
	qr.Init(&Info,&bmp,this); 

	int n=qr.info->TotalMsgChars/qr.TGroupData;
	int rembytes=qr.info->TotalMsgChars % qr.TGroupData;

	char *ptr,textoutfname[300]; sprintf(textoutfname,"%s.txt",dlgset.ImageFilePathOut);
	FILE *fp=fopen(textoutfname,"wt");
	if(fp==NULL){ MessageBox("Error: Unable to create output .txt file"); return; }
	//fprintf(fp,"Read message is\n\n");

	//Initilize groupno
	qr.ReadStegoPixelBytes(0,1);

	//Read message from pixels
	for(int i=0;i<n;i++)
	{ 
		ptr=qr.ReadStegoPixelBytes(qr.TGroupData);
		fprintf(fp,"%s",ptr); 
	}

	if(rembytes!=0)
	{
		//Read last remainder message chars
		ptr=qr.ReadStegoPixelBytes(rembytes);
		fprintf(fp,"%s",ptr); 
	}

	fclose(fp);
	Display_INFO_struct("Read Message will be opened in file"); 

	ShellExecute(NULL,_T("open"),textoutfname,NULL,NULL,SW_SHOW);
}






void CEditBMPVCDlg::OnOK() 
{
	//** Update struct and write it to setting.stg file
	GetDlgItemText(IDC_EDIT1,dlgset.DataGroupSize,15); 
	GetDlgItemText(IDC_EDIT2,dlgset.PixelGroupSize,15); 
	GetDlgItemText(IDC_EDIT3,dlgset.StartDataPixel,15); 
	GetDlgItemText(IDC_EDIT4,dlgset.DataPixelMapping,495); 

	GetDlgItemText(IDC_COMBO1,dlgset.PercentData,15);
	GetDlgItemText(IDC_COMBO2,dlgset.FixedData,15);

	dlgset.nProfile=((CComboBox*)GetDlgItem(IDC_COMBO3))->GetCurSel();

	char buff[500]; 
	sprintf(buff,"%s\\settings.stg",TempFolder);
	FILE *fp=fopen(buff,"wb"); 
	if(fp!=NULL){ fwrite(&dlgset,sizeof(DLGSETTING),1,fp); fclose(fp); }

	//Write QR_INFO struct to TempFolder file instead in .bmp stego file to help decode info later from stego file.
	//Write_QRINFO_struct();


	//*********************************
	CDialog::OnOK();
}





void CEditBMPVCDlg::OnRadio1_WholeFile() 
{
   GetDlgItem(IDC_COMBO1)->EnableWindow(0);
   GetDlgItem(IDC_COMBO2)->EnableWindow(0);
   dlgset.RadioValueMsgSize=0;
}



void CEditBMPVCDlg::OnRadio2_PercentCapacity() 
{
   GetDlgItem(IDC_COMBO1)->EnableWindow(1);
   GetDlgItem(IDC_COMBO2)->EnableWindow(0);
   dlgset.RadioValueMsgSize=1;
}



void CEditBMPVCDlg::OnRadio3_FillFixedData() 
{
   GetDlgItem(IDC_COMBO1)->EnableWindow(0);
   GetDlgItem(IDC_COMBO2)->EnableWindow(1);
   dlgset.RadioValueMsgSize=2;
}


void CEditBMPVCDlg::OnSelchangeCombo3_ChangeProfile() 
{
	//char *profile[50]={ "","3 chars -> 2 Pixels   (1.5 byte/pixel)","1 char -> 1 Pixel    (1 byte/pixel)","3 chars -> 4 Pixels   (0.75 byte/pixel)","2 chars -> 3 Pixels   (0.66 byte/pixel)","1 char -> 2 Pixels   (0.50 byte/pixel)","2 chars -> 5 Pixels   (0.40 byte/pixel)","1 char -> 3 Pixels   (0.33 byte/pixel)",""};
	char *GroupData1[10]={ "3","1","3","2","1","2","1" };
	char *GroupPix1[10]= { "2","1","4","3","2","5","3" };
	char *DataPixmap1[10]={"0,1,2,3,4,5", "0,1", "0,9,3,10,6,11", "0,3,6,7", "0,3", "0,3,6,9", "0,3" };

	int val=((CComboBox*)GetDlgItem(IDC_COMBO3))->GetCurSel();
	SetDlgItemText(IDC_EDIT1,GroupData1[val]);
	SetDlgItemText(IDC_EDIT2,GroupPix1[val]);
	SetDlgItemText(IDC_EDIT4,DataPixmap1[val]);
	
}






void CEditBMPVCDlg::OnButton1_EditPixelExample() 
{

   //char buff[2000];

   //sprintf(buff,"Size of header: %d",sizeof(HEADER));
   //MessageBox(buff); return;

   CString st=dlgset.ImageFilePath; st.MakeLower(); int pos=st.Find(".bmp");
   if(pos==-1){ MessageBox("Browse .bmp as input file"); return; }

   EditBMP obj;
   obj.ReadBMPFile(dlgset.ImageFilePath);

   //Write all pixels of file.
   for(int i=0;i<obj.pixelwidth;i++)
     {
      for(int j=0;j<obj.pixelheight;j++)
	 {
	   //obj.PutPixel(j,i, (i%3==0)*255, (i%3==1)*255, (i%3==2)*255);  //Make colored row bands.
	   obj.PutPixel(i,j, 0,0,0); //Set all pixels to black
	 }
     }

   //Write 2nd row pixels for verification.
   //for(i=0;i<obj.pixelwidth;i++) obj.PutPixel(i,1,0,0,255);

   //write 1,1 pixel for verification.
   obj.PutPixel(1,1,5,10,250);


   //Write file. Check output file.
   obj.WriteBMPFile(dlgset.ImageFilePathOut);

   char buff[500]; 
   sprintf(buff,"%s\\PixelDetails.txt",TempFolder);
   FILE *fp=fopen(buff,"wt"); 

   EditBMP obj1;
   obj1.ReadBMPFile(dlgset.ImageFilePathOut);
   for(i=0;i<obj1.pixelwidth;i++)
     {
       obj1.GetPixel(i,1);
       fprintf(fp,"\n%d  %d  %d",obj1.b,obj1.g,obj1.r);
     }


   //Read (1,1) pixel
   obj.GetPixel(1,1);
   fprintf(fp,"\n\n (1,1) Pixel:  b=%d  g=%d  r=%d",obj.b,obj.g,obj.r);

   fclose(fp);

   ShellExecute(NULL,_T("open"),buff,NULL,NULL,SW_SHOW);
}



void CEditBMPVCDlg::OnButton8_BrowseStegoFile() 
{
	//Select filename
	CFileDialog  file(TRUE,NULL,NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,"Bitmap Files (*.bmp)|*.bmp|All Files (*.*)|*.*||",NULL);
    if(file.DoModal()==IDCANCEL)return;
    
	//Save ImageFile Path and Name to struct
	strcpy(dlgset.ImageFilePathOut,file.GetPathName()); strlwr(dlgset.ImageFilePath);

	//Validate selected file
    CString st=dlgset.ImageFilePathOut; st.MakeLower();  int pos=st.Find(".bmp");
    if(pos==-1){ MessageBox("Browse file with .bmp extension only"); return; }

	//Display Loaded file name
	SetDlgItemText(IDC_STATIC3,dlgset.ImageFilePathOut);
}

void CEditBMPVCDlg::OnCheck1_UsePassword() 
{
	int IsPass=((CButton*)GetDlgItem(IDC_CHECK1))->GetCheck();
	GetDlgItem(IDC_EDIT5)->EnableWindow(IsPass);
	
}
