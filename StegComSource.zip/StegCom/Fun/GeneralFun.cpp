
char TempFolder[500];
int GetTempFolderPath()
{
  char *p;
  p=getenv("APPDATA"); if(p!=NULL)goto end;  
  p=getenv("TEMP");if(p!=NULL)goto end;  
  p=getenv("TMP"); if(p!=NULL)goto end;  
  p=getenv("USERPROFILE"); if(p!=NULL)goto end;
  TempFolder[0]=0;
  return(0);

end:

    //Check existence of S_P_B folder under above found folder.
    sprintf(TempFolder,"%s\\SUKH",p);   
    CFileFind a; int value=a.FindFile(TempFolder);

	//If folder already exists.
	if(value)return(1);

	//Create S_P_B folder
	value=_mkdir(TempFolder); 
	if(value==0)return(1); else { strcpy(TempFolder,p); return(1);  }  

}






int GetFolderFilePaths(char *folder, CString *PathList, CString *TitleList, CString *FileName, CString *FolderPath, char *extension,char *ExcludeStr,int MaxFiles)
{

   //if folder="c:\abc\table.txt" then make it "c:\abc\*.*" in folder1
   char folder1[500],*s=folder1,ext[100],ExcludeStr1[500];
   
   strcpy(folder1,folder); 
   strcpy(ext,extension); strlwr(ext);
   strcpy(ExcludeStr1,ExcludeStr); strlwr(ExcludeStr1);

	//Append *.* after folder name if not there.
   while(*s)s++; s--; 
   if(*s!='*' && *s!='\\')
   {
		while(s>folder1 && *s!='\\')s--; 
		if(*s=='\\')strcpy(s,"\\*.*");  else return(0);
   } else { if(*s=='\\')strcat(s,"\\*.*"); }
   

   //Set Folderpath
   int len=strlen(folder1);
   *FolderPath=folder1; 
   FolderPath->Delete(len-4,4);

   

   //Start finding files now
   int nPathList=0;  

	CFileFind f;
	BOOL found=f.FindFile(folder1,0);
	if(found==0)return(0);

	CString st; int pos;
    while(found)
    {
      found=f.FindNextFile();
	  if(f.IsDirectory())continue;
      st=f.GetFilePath(); st.MakeLower(); pos=st.Find(ext); if(pos==-1)continue;
	  if(ExcludeStr1[0]!=0){ pos=st.Find(ExcludeStr1); if(pos>0)continue; }

	  PathList[nPathList]=f.GetFilePath();
	  TitleList[nPathList]=f.GetFileTitle();
	  FileName[nPathList++]=f.GetFileName();

	  if(nPathList>=MaxFiles)break;
	}
	return(nPathList);
}



CString FindOutputFileName(const char *InputFname)
{

	char fname[900],temp[200],*s=fname;
	strcpy(fname,InputFname);

	//Find . from end and replace insert "_out" here
    while(*s)s++; s--; 
	while(s>fname && *s!='\\')s--; 
	if(*s=='\\'){ s++; strcpy(temp,s); strcpy(s,"Stego-"); strcat(s,temp); } //if filepath
	if(s==fname){ strcpy(temp,s); strcpy(s,"Stego-"); strcat(s,temp); } //if only filename

	CString OutFname=fname;
	return(OutFname);
}



void InsertCharAtBeg(char ch,char *s)
{
	int len=strlen(s);
	char *buff=new char[len+10];

	strcpy(buff,s); s[0]=ch; strcpy(s+1,buff);
	delete buff;
}


//Return Total number of integers in array
int Str2Int(char *str,int *array)
{
	int index=0;
	for(char *p=str;1;)
	{ 
		while(!isdigit(*p) && *p!=0)p++; if(*p==0)return(index);
		array[index++]=atoi(p); 
		while(isdigit(*p) && *p!=0)p++; if(*p==0)return(index);
	}
	
	return(index);
}
